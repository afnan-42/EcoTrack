
-- Add onboarding_completed to profiles
ALTER TABLE public.profiles ADD COLUMN IF NOT EXISTS onboarding_completed boolean NOT NULL DEFAULT false;

-- Add water and shopping columns to carbon_activities
ALTER TABLE public.carbon_activities ADD COLUMN IF NOT EXISTS water_liters numeric DEFAULT 0;
ALTER TABLE public.carbon_activities ADD COLUMN IF NOT EXISTS shopping_items integer DEFAULT 0;
ALTER TABLE public.carbon_activities ADD COLUMN IF NOT EXISTS streaming_hours numeric DEFAULT 0;
ALTER TABLE public.carbon_activities ADD COLUMN IF NOT EXISTS waste_kg numeric DEFAULT 0;

-- Create challenges table
CREATE TABLE IF NOT EXISTS public.challenges (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  title text NOT NULL,
  description text NOT NULL,
  category text NOT NULL,
  icon text NOT NULL DEFAULT '🌱',
  target_value numeric NOT NULL DEFAULT 1,
  target_unit text NOT NULL DEFAULT 'times',
  points integer NOT NULL DEFAULT 10,
  difficulty text NOT NULL DEFAULT 'easy',
  created_at timestamptz NOT NULL DEFAULT now()
);

ALTER TABLE public.challenges ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Anyone can view challenges" ON public.challenges FOR SELECT TO authenticated USING (true);

-- Create user_challenges table
CREATE TABLE IF NOT EXISTS public.user_challenges (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  challenge_id uuid NOT NULL REFERENCES public.challenges(id) ON DELETE CASCADE,
  status text NOT NULL DEFAULT 'active',
  progress numeric NOT NULL DEFAULT 0,
  completed_at timestamptz,
  started_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE(user_id, challenge_id)
);

ALTER TABLE public.user_challenges ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users can view own challenges" ON public.user_challenges FOR SELECT TO authenticated USING (auth.uid() = user_id);
CREATE POLICY "Users can insert own challenges" ON public.user_challenges FOR INSERT TO authenticated WITH CHECK (auth.uid() = user_id);
CREATE POLICY "Users can update own challenges" ON public.user_challenges FOR UPDATE TO authenticated USING (auth.uid() = user_id);

-- Insert seed challenges
INSERT INTO public.challenges (title, description, category, icon, target_value, target_unit, points, difficulty) VALUES
('Car-Free Week', 'Go an entire week without using a car', 'transport', '🚗', 7, 'days', 50, 'medium'),
('Meatless Monday', 'Go vegetarian for a full day', 'food', '🥗', 1, 'days', 10, 'easy'),
('Power Down', 'Reduce electricity usage by 10% this month', 'energy', '⚡', 10, 'percent', 30, 'medium'),
('Cycle Commuter', 'Bike to work/school 5 times', 'transport', '🚴', 5, 'trips', 40, 'medium'),
('Zero Waste Day', 'Produce no waste for an entire day', 'lifestyle', '♻️', 1, 'days', 25, 'hard'),
('Plant a Tree', 'Plant a tree to offset emissions', 'nature', '🌳', 1, 'trees', 100, 'easy'),
('Cold Shower Week', 'Take cold showers for 7 days to save energy', 'energy', '🚿', 7, 'days', 35, 'hard'),
('Local Food Only', 'Eat only locally sourced food for a week', 'food', '🌽', 7, 'days', 45, 'hard'),
('Public Transit Pro', 'Use public transport 10 times this month', 'transport', '🚌', 10, 'trips', 30, 'easy'),
('Digital Detox', 'Reduce streaming by 50% for a week', 'lifestyle', '📱', 7, 'days', 20, 'medium'),
('Veggie Week', 'Go fully vegetarian for 7 days', 'food', '🥬', 7, 'days', 40, 'medium'),
('Walk 10K Steps', 'Walk 10,000 steps instead of driving', 'transport', '🚶', 10000, 'steps', 15, 'easy');
