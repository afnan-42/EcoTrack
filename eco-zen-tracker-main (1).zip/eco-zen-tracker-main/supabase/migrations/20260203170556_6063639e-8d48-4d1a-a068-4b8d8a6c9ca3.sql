-- Create profiles table for user data
CREATE TABLE public.profiles (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  user_id UUID NOT NULL UNIQUE REFERENCES auth.users(id) ON DELETE CASCADE,
  name TEXT,
  city_pincode TEXT NOT NULL DEFAULT '000000',
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Enable RLS
ALTER TABLE public.profiles ENABLE ROW LEVEL SECURITY;

-- Profiles policies
CREATE POLICY "Users can view their own profile" 
ON public.profiles FOR SELECT 
USING (auth.uid() = user_id);

CREATE POLICY "Users can insert their own profile" 
ON public.profiles FOR INSERT 
WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can update their own profile" 
ON public.profiles FOR UPDATE 
USING (auth.uid() = user_id);

-- Create carbon activities table for daily/weekly inputs
CREATE TABLE public.carbon_activities (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  user_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  activity_date DATE NOT NULL,
  input_type TEXT NOT NULL CHECK (input_type IN ('daily', 'weekly', 'monthly')),
  
  -- Transportation
  transport_mode TEXT,
  transport_distance_km NUMERIC DEFAULT 0,
  
  -- Food habits (for weekly)
  non_veg_days INTEGER DEFAULT 0,
  
  -- Monthly utilities
  electricity_units NUMERIC DEFAULT 0,
  gas_lpg_kg NUMERIC DEFAULT 0,
  
  -- High-impact occasional activities
  flight_hours NUMERIC DEFAULT 0,
  
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Enable RLS
ALTER TABLE public.carbon_activities ENABLE ROW LEVEL SECURITY;

-- Activities policies
CREATE POLICY "Users can view their own activities" 
ON public.carbon_activities FOR SELECT 
USING (auth.uid() = user_id);

CREATE POLICY "Users can insert their own activities" 
ON public.carbon_activities FOR INSERT 
WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can update their own activities" 
ON public.carbon_activities FOR UPDATE 
USING (auth.uid() = user_id);

CREATE POLICY "Users can delete their own activities" 
ON public.carbon_activities FOR DELETE 
USING (auth.uid() = user_id);

-- Create monthly footprints table (normalized data for community features)
CREATE TABLE public.monthly_footprints (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  user_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  month DATE NOT NULL,
  total_kg NUMERIC NOT NULL DEFAULT 0,
  transport_kg NUMERIC DEFAULT 0,
  food_kg NUMERIC DEFAULT 0,
  energy_kg NUMERIC DEFAULT 0,
  other_kg NUMERIC DEFAULT 0,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  UNIQUE(user_id, month)
);

-- Enable RLS
ALTER TABLE public.monthly_footprints ENABLE ROW LEVEL SECURITY;

-- Footprints policies - users can view their own
CREATE POLICY "Users can view their own footprints" 
ON public.monthly_footprints FOR SELECT 
USING (auth.uid() = user_id);

CREATE POLICY "Users can insert their own footprints" 
ON public.monthly_footprints FOR INSERT 
WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can update their own footprints" 
ON public.monthly_footprints FOR UPDATE 
USING (auth.uid() = user_id);

-- Community view policy - allow reading aggregate data within same city
CREATE POLICY "Users can view community footprints in same city"
ON public.monthly_footprints FOR SELECT
USING (
  EXISTS (
    SELECT 1 FROM public.profiles p1
    WHERE p1.user_id = auth.uid()
    AND p1.city_pincode = (
      SELECT p2.city_pincode FROM public.profiles p2 
      WHERE p2.user_id = monthly_footprints.user_id
    )
  )
);

-- Create AI chat messages table for personal assistant
CREATE TABLE public.ai_chat_messages (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  user_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  role TEXT NOT NULL CHECK (role IN ('user', 'assistant')),
  content TEXT NOT NULL,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Enable RLS
ALTER TABLE public.ai_chat_messages ENABLE ROW LEVEL SECURITY;

-- Chat policies
CREATE POLICY "Users can view their own messages" 
ON public.ai_chat_messages FOR SELECT 
USING (auth.uid() = user_id);

CREATE POLICY "Users can insert their own messages" 
ON public.ai_chat_messages FOR INSERT 
WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can delete their own messages" 
ON public.ai_chat_messages FOR DELETE 
USING (auth.uid() = user_id);

-- Create updated_at trigger function
CREATE OR REPLACE FUNCTION public.update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = now();
  RETURN NEW;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER SET search_path = '';

-- Apply trigger to all tables
CREATE TRIGGER update_profiles_updated_at
BEFORE UPDATE ON public.profiles
FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();

CREATE TRIGGER update_carbon_activities_updated_at
BEFORE UPDATE ON public.carbon_activities
FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();

CREATE TRIGGER update_monthly_footprints_updated_at
BEFORE UPDATE ON public.monthly_footprints
FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();

-- Auto-create profile on user signup
CREATE OR REPLACE FUNCTION public.handle_new_user()
RETURNS TRIGGER AS $$
BEGIN
  INSERT INTO public.profiles (user_id, name)
  VALUES (NEW.id, COALESCE(NEW.raw_user_meta_data->>'name', NEW.email));
  RETURN NEW;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER SET search_path = '';

CREATE TRIGGER on_auth_user_created
AFTER INSERT ON auth.users
FOR EACH ROW EXECUTE FUNCTION public.handle_new_user();

-- Create indexes for performance
CREATE INDEX idx_carbon_activities_user_date ON public.carbon_activities(user_id, activity_date);
CREATE INDEX idx_monthly_footprints_user_month ON public.monthly_footprints(user_id, month);
CREATE INDEX idx_profiles_city ON public.profiles(city_pincode);
CREATE INDEX idx_ai_chat_messages_user ON public.ai_chat_messages(user_id, created_at);

-- Database functions for community features (rule-based, no AI)

-- Get city average footprint for a given month
CREATE OR REPLACE FUNCTION public.get_city_average(p_user_id UUID, p_month DATE)
RETURNS TABLE(city_average NUMERIC, total_users BIGINT, city_pincode TEXT) AS $$
BEGIN
  RETURN QUERY
  SELECT 
    COALESCE(AVG(mf.total_kg), 0) as city_average,
    COUNT(DISTINCT mf.user_id) as total_users,
    pr.city_pincode
  FROM public.profiles pr
  LEFT JOIN public.monthly_footprints mf ON mf.user_id = pr.user_id AND mf.month = p_month
  WHERE pr.city_pincode = (SELECT city_pincode FROM public.profiles WHERE user_id = p_user_id)
  GROUP BY pr.city_pincode;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER SET search_path = '';

-- Get user rank within city for a given month
CREATE OR REPLACE FUNCTION public.get_user_rank(p_user_id UUID, p_month DATE)
RETURNS TABLE(user_rank BIGINT, percentile NUMERIC, user_footprint NUMERIC, total_users BIGINT) AS $$
DECLARE
  v_city_pincode TEXT;
  v_user_footprint NUMERIC;
  v_lower_count BIGINT;
  v_total BIGINT;
BEGIN
  -- Get user's city
  SELECT city_pincode INTO v_city_pincode FROM public.profiles WHERE user_id = p_user_id;
  
  -- Get user's footprint for the month
  SELECT total_kg INTO v_user_footprint FROM public.monthly_footprints 
  WHERE user_id = p_user_id AND month = p_month;
  
  IF v_user_footprint IS NULL THEN
    RETURN QUERY SELECT NULL::BIGINT, NULL::NUMERIC, NULL::NUMERIC, NULL::BIGINT;
    RETURN;
  END IF;
  
  -- Count users with lower emissions in same city
  SELECT COUNT(*) INTO v_lower_count
  FROM public.monthly_footprints mf
  JOIN public.profiles pr ON pr.user_id = mf.user_id
  WHERE pr.city_pincode = v_city_pincode 
    AND mf.month = p_month 
    AND mf.total_kg < v_user_footprint;
  
  -- Total users in city with footprint data
  SELECT COUNT(DISTINCT mf.user_id) INTO v_total
  FROM public.monthly_footprints mf
  JOIN public.profiles pr ON pr.user_id = mf.user_id
  WHERE pr.city_pincode = v_city_pincode AND mf.month = p_month;
  
  -- Rank formula: count(users with lower emissions) + 1
  RETURN QUERY SELECT 
    v_lower_count + 1,
    CASE WHEN v_total > 1 THEN ROUND(((v_total - v_lower_count - 1)::NUMERIC / (v_total - 1)::NUMERIC) * 100, 1) ELSE 100.0 END,
    v_user_footprint,
    v_total;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER SET search_path = '';

-- Get city leaderboard (top 10 lowest emissions)
CREATE OR REPLACE FUNCTION public.get_city_leaderboard(p_user_id UUID, p_month DATE)
RETURNS TABLE(rank BIGINT, user_name TEXT, total_kg NUMERIC) AS $$
DECLARE
  v_city_pincode TEXT;
BEGIN
  SELECT city_pincode INTO v_city_pincode FROM public.profiles WHERE user_id = p_user_id;
  
  RETURN QUERY
  SELECT 
    ROW_NUMBER() OVER (ORDER BY mf.total_kg ASC) as rank,
    COALESCE(pr.name, 'Anonymous') as user_name,
    mf.total_kg
  FROM public.monthly_footprints mf
  JOIN public.profiles pr ON pr.user_id = mf.user_id
  WHERE pr.city_pincode = v_city_pincode AND mf.month = p_month
  ORDER BY mf.total_kg ASC
  LIMIT 10;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER SET search_path = '';