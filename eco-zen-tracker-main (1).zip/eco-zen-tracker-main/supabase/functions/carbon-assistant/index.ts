import { serve } from "https://deno.land/std@0.168.0/http/server.ts";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type, x-supabase-client-platform, x-supabase-client-platform-version, x-supabase-client-runtime, x-supabase-client-runtime-version",
};

const systemPrompt = `You are EcoTrack's AI sustainability assistant. You help users understand and reduce their carbon footprint.

Your role:
- Analyze personal carbon footprint trends and provide insights
- Give personalized recommendations to reduce emissions
- Answer questions about sustainability and environmental impact
- Explain why certain activities contribute more to carbon emissions
- Be encouraging and practical in your suggestions

Key emission factors to reference:
- Car: 0.21 kg CO₂/km | Electric car: 0.053 kg CO₂/km
- Bus: 0.089 kg CO₂/km | Train: 0.041 kg CO₂/km
- Flight: ~204 kg CO₂/hour
- Non-vegetarian meal: ~7.2 kg CO₂/day vs vegetarian: ~3.8 kg CO₂/day
- Electricity: ~0.82 kg CO₂/kWh | LPG: ~2.98 kg CO₂/kg

Be concise, friendly, and actionable. Use emojis sparingly to keep responses engaging.`;

serve(async (req) => {
  if (req.method === "OPTIONS") {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const { messages } = await req.json();
    const LOVABLE_API_KEY = Deno.env.get("LOVABLE_API_KEY");
    
    if (!LOVABLE_API_KEY) {
      throw new Error("LOVABLE_API_KEY is not configured");
    }

    const response = await fetch("https://ai.gateway.lovable.dev/v1/chat/completions", {
      method: "POST",
      headers: {
        Authorization: `Bearer ${LOVABLE_API_KEY}`,
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        model: "google/gemini-3-flash-preview",
        messages: [
          { role: "system", content: systemPrompt },
          ...messages,
        ],
        stream: true,
      }),
    });

    if (!response.ok) {
      if (response.status === 429) {
        return new Response(JSON.stringify({ error: "Rate limit exceeded" }), {
          status: 429,
          headers: { ...corsHeaders, "Content-Type": "application/json" },
        });
      }
      if (response.status === 402) {
        return new Response(JSON.stringify({ error: "Payment required" }), {
          status: 402,
          headers: { ...corsHeaders, "Content-Type": "application/json" },
        });
      }
      throw new Error("AI gateway error");
    }

    return new Response(response.body, {
      headers: { ...corsHeaders, "Content-Type": "text/event-stream" },
    });
  } catch (e) {
    console.error("Error:", e);
    return new Response(JSON.stringify({ error: e instanceof Error ? e.message : "Unknown error" }), {
      status: 500,
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  }
});
