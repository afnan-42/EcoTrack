// Emission factors (kg CO2 per unit)
export const EMISSION_FACTORS = {
  // Transport (kg CO2 per km)
  transport: {
    car: 0.21,
    bus: 0.089,
    train: 0.041,
    bike: 0,
    walk: 0,
    motorcycle: 0.113,
    electric_car: 0.053,
    flight: 0.255, // per km, but we use hours (avg 800km/h)
    auto_rickshaw: 0.098,
    metro: 0.033,
    carpool: 0.07,
  },

  // Food (kg CO2 per day)
  food: {
    non_veg_day: 7.2,
    veg_day: 3.8,
  },

  // Energy (kg CO2 per unit)
  energy: {
    electricity_per_unit: 0.82, // kWh
    gas_lpg_per_kg: 2.98,
  },

  // Water (kg CO2 per liter)
  water_per_liter: 0.000298,

  // Shopping (kg CO2 per item - average clothing/electronics)
  shopping_per_item: 8.5,

  // Streaming (kg CO2 per hour - data center energy)
  streaming_per_hour: 0.036,

  // Waste (kg CO2 per kg of waste)
  waste_per_kg: 0.587,

  // Flight (kg CO2 per hour - avg 800km/h * 0.255)
  flight_per_hour: 204,
};

export interface CarbonActivity {
  input_type: 'daily' | 'weekly' | 'monthly';
  transport_mode?: string;
  transport_distance_km?: number;
  non_veg_days?: number;
  electricity_units?: number;
  gas_lpg_kg?: number;
  flight_hours?: number;
  water_liters?: number;
  shopping_items?: number;
  streaming_hours?: number;
  waste_kg?: number;
}

export interface MonthlyBreakdown {
  transport_kg: number;
  food_kg: number;
  energy_kg: number;
  other_kg: number;
  total_kg: number;
}

// Normalize activities to monthly estimates
export function calculateMonthlyFootprint(activities: CarbonActivity[]): MonthlyBreakdown {
  let transport_kg = 0;
  let food_kg = 0;
  let energy_kg = 0;
  let other_kg = 0;

  activities.forEach((activity) => {
    const multiplier = getMonthlyMultiplier(activity.input_type);

    // Transport calculation
    if (activity.transport_mode && activity.transport_distance_km) {
      const factor = EMISSION_FACTORS.transport[activity.transport_mode as keyof typeof EMISSION_FACTORS.transport] || 0.15;
      transport_kg += activity.transport_distance_km * factor * multiplier;
    }

    // Flight calculation
    if (activity.flight_hours) {
      other_kg += activity.flight_hours * EMISSION_FACTORS.flight_per_hour * multiplier;
    }

    // Food calculation (weekly)
    if (activity.non_veg_days !== undefined) {
      const weekMultiplier = activity.input_type === 'weekly' ? 4 : 1;
      const veg_days = 7 - activity.non_veg_days;
      food_kg += (activity.non_veg_days * EMISSION_FACTORS.food.non_veg_day +
                  veg_days * EMISSION_FACTORS.food.veg_day) * weekMultiplier;
    }

    // Energy calculation (monthly)
    if (activity.electricity_units) {
      energy_kg += activity.electricity_units * EMISSION_FACTORS.energy.electricity_per_unit;
    }
    if (activity.gas_lpg_kg) {
      energy_kg += activity.gas_lpg_kg * EMISSION_FACTORS.energy.gas_lpg_per_kg;
    }

    // Water calculation
    if (activity.water_liters) {
      other_kg += activity.water_liters * EMISSION_FACTORS.water_per_liter * multiplier;
    }

    // Shopping calculation
    if (activity.shopping_items) {
      other_kg += activity.shopping_items * EMISSION_FACTORS.shopping_per_item * multiplier;
    }

    // Streaming calculation
    if (activity.streaming_hours) {
      other_kg += activity.streaming_hours * EMISSION_FACTORS.streaming_per_hour * multiplier;
    }

    // Waste calculation
    if (activity.waste_kg) {
      other_kg += activity.waste_kg * EMISSION_FACTORS.waste_per_kg * multiplier;
    }
  });

  const total_kg = transport_kg + food_kg + energy_kg + other_kg;

  return {
    transport_kg: Math.round(transport_kg * 100) / 100,
    food_kg: Math.round(food_kg * 100) / 100,
    energy_kg: Math.round(energy_kg * 100) / 100,
    other_kg: Math.round(other_kg * 100) / 100,
    total_kg: Math.round(total_kg * 100) / 100,
  };
}

function getMonthlyMultiplier(inputType: string): number {
  switch (inputType) {
    case 'daily':
      return 30;
    case 'weekly':
      return 4;
    case 'monthly':
      return 1;
    default:
      return 1;
  }
}

export function getCarbonLevel(totalKg: number): 'low' | 'medium' | 'high' | 'critical' {
  if (totalKg < 200) return 'low';
  if (totalKg < 400) return 'medium';
  if (totalKg < 600) return 'high';
  return 'critical';
}

export function getCarbonLevelColor(level: string): string {
  switch (level) {
    case 'low':
      return 'text-carbon-low';
    case 'medium':
      return 'text-carbon-medium';
    case 'high':
      return 'text-carbon-high';
    case 'critical':
      return 'text-carbon-critical';
    default:
      return 'text-muted-foreground';
  }
}

export function getTransportModes() {
  return [
    { value: 'car', label: 'Car', icon: '🚗' },
    { value: 'electric_car', label: 'Electric Car', icon: '🔋' },
    { value: 'bus', label: 'Bus', icon: '🚌' },
    { value: 'train', label: 'Train', icon: '🚂' },
    { value: 'metro', label: 'Metro', icon: '🚇' },
    { value: 'motorcycle', label: 'Motorcycle', icon: '🏍️' },
    { value: 'auto_rickshaw', label: 'Auto Rickshaw', icon: '🛺' },
    { value: 'carpool', label: 'Carpool', icon: '🚙' },
    { value: 'bike', label: 'Bicycle', icon: '🚴' },
    { value: 'walk', label: 'Walking', icon: '🚶' },
  ];
}

// Quick estimate from onboarding answers
export function estimateFromOnboarding(data: {
  transportMode: string;
  dailyCommuteKm: number;
  nonVegDaysPerWeek: number;
  electricityUnits: number;
  gasKg: number;
  flightHoursPerMonth: number;
  waterLitersPerDay: number;
  shoppingItemsPerMonth: number;
  streamingHoursPerDay: number;
  wasteKgPerWeek: number;
}): MonthlyBreakdown {
  const activities: CarbonActivity[] = [
    {
      input_type: 'daily',
      transport_mode: data.transportMode,
      transport_distance_km: data.dailyCommuteKm,
      streaming_hours: data.streamingHoursPerDay,
      water_liters: data.waterLitersPerDay,
    },
    {
      input_type: 'weekly',
      non_veg_days: data.nonVegDaysPerWeek,
      waste_kg: data.wasteKgPerWeek,
    },
    {
      input_type: 'monthly',
      electricity_units: data.electricityUnits,
      gas_lpg_kg: data.gasKg,
      flight_hours: data.flightHoursPerMonth,
      shopping_items: data.shoppingItemsPerMonth,
    },
  ];

  return calculateMonthlyFootprint(activities);
}
