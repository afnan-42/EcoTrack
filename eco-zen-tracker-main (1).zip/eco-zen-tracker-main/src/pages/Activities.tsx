import { useState } from 'react';
import { motion } from 'framer-motion';
import {
  Calendar, Car, Utensils, Zap, Plane, Check, ChevronRight, Plus,
  Droplets, ShoppingBag, MonitorPlay, Trash2
} from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Layout } from '@/components/Layout';
import { useAuth } from '@/hooks/useAuth';
import { supabase } from '@/integrations/supabase/client';
import { getTransportModes, calculateMonthlyFootprint } from '@/lib/carbonCalculations';
import { useToast } from '@/hooks/use-toast';
import { format } from 'date-fns';

export default function Activities() {
  const { user } = useAuth();
  const { toast } = useToast();
  const [loading, setLoading] = useState(false);
  const [activeTab, setActiveTab] = useState('daily');

  // Daily
  const [transportMode, setTransportMode] = useState('');
  const [transportDistance, setTransportDistance] = useState('');
  const [flightHours, setFlightHours] = useState('');
  const [waterLiters, setWaterLiters] = useState('');
  const [streamingHours, setStreamingHours] = useState('');

  // Weekly
  const [weeklyDistance, setWeeklyDistance] = useState('');
  const [weeklyTransportMode, setWeeklyTransportMode] = useState('');
  const [nonVegDays, setNonVegDays] = useState('');
  const [wasteKg, setWasteKg] = useState('');

  // Monthly
  const [electricityUnits, setElectricityUnits] = useState('');
  const [gasLpgKg, setGasLpgKg] = useState('');
  const [shoppingItems, setShoppingItems] = useState('');

  const transportModes = getTransportModes();

  const handleDailySubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!user) return;
    setLoading(true);
    try {
      const { error } = await supabase.from('carbon_activities').insert({
        user_id: user.id,
        activity_date: format(new Date(), 'yyyy-MM-dd'),
        input_type: 'daily',
        transport_mode: transportMode || null,
        transport_distance_km: transportDistance ? parseFloat(transportDistance) : 0,
        flight_hours: flightHours ? parseFloat(flightHours) : 0,
        water_liters: waterLiters ? parseFloat(waterLiters) : 0,
        streaming_hours: streamingHours ? parseFloat(streamingHours) : 0,
      });
      if (error) throw error;
      toast({ title: 'Activity logged!', description: 'Your daily activity has been recorded.' });
      setTransportMode(''); setTransportDistance(''); setFlightHours('');
      setWaterLiters(''); setStreamingHours('');
      await updateMonthlyFootprint();
    } catch (error) {
      console.error(error);
      toast({ title: 'Error', description: 'Failed to log activity.', variant: 'destructive' });
    } finally { setLoading(false); }
  };

  const handleWeeklySubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!user) return;
    setLoading(true);
    try {
      const { error } = await supabase.from('carbon_activities').insert({
        user_id: user.id,
        activity_date: format(new Date(), 'yyyy-MM-dd'),
        input_type: 'weekly',
        transport_mode: weeklyTransportMode || null,
        transport_distance_km: weeklyDistance ? parseFloat(weeklyDistance) : 0,
        non_veg_days: nonVegDays ? parseInt(nonVegDays) : 0,
        waste_kg: wasteKg ? parseFloat(wasteKg) : 0,
      });
      if (error) throw error;
      toast({ title: 'Weekly activity logged!' });
      setWeeklyDistance(''); setWeeklyTransportMode(''); setNonVegDays(''); setWasteKg('');
      await updateMonthlyFootprint();
    } catch (error) {
      console.error(error);
      toast({ title: 'Error', description: 'Failed to log activity.', variant: 'destructive' });
    } finally { setLoading(false); }
  };

  const handleMonthlySubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!user) return;
    setLoading(true);
    try {
      const { error } = await supabase.from('carbon_activities').insert({
        user_id: user.id,
        activity_date: format(new Date(), 'yyyy-MM-dd'),
        input_type: 'monthly',
        electricity_units: electricityUnits ? parseFloat(electricityUnits) : 0,
        gas_lpg_kg: gasLpgKg ? parseFloat(gasLpgKg) : 0,
        shopping_items: shoppingItems ? parseInt(shoppingItems) : 0,
      });
      if (error) throw error;
      toast({ title: 'Monthly data logged!' });
      setElectricityUnits(''); setGasLpgKg(''); setShoppingItems('');
      await updateMonthlyFootprint();
    } catch (error) {
      console.error(error);
      toast({ title: 'Error', description: 'Failed to log data.', variant: 'destructive' });
    } finally { setLoading(false); }
  };

  const updateMonthlyFootprint = async () => {
    if (!user) return;
    try {
      const currentMonth = format(new Date(), 'yyyy-MM-01');
      const { data: activities } = await supabase
        .from('carbon_activities').select('*')
        .eq('user_id', user.id).gte('activity_date', currentMonth);

      if (activities) {
        const mapped = activities.map((a: any) => ({
          input_type: a.input_type as 'daily' | 'weekly' | 'monthly',
          transport_mode: a.transport_mode || undefined,
          transport_distance_km: a.transport_distance_km || undefined,
          non_veg_days: a.non_veg_days || undefined,
          electricity_units: a.electricity_units || undefined,
          gas_lpg_kg: a.gas_lpg_kg || undefined,
          flight_hours: a.flight_hours || undefined,
          water_liters: a.water_liters || undefined,
          shopping_items: a.shopping_items || undefined,
          streaming_hours: a.streaming_hours || undefined,
          waste_kg: a.waste_kg || undefined,
        }));
        const footprint = calculateMonthlyFootprint(mapped);
        await supabase.from('monthly_footprints').upsert({
          user_id: user.id, month: currentMonth,
          total_kg: footprint.total_kg, transport_kg: footprint.transport_kg,
          food_kg: footprint.food_kg, energy_kg: footprint.energy_kg,
          other_kg: footprint.other_kg,
        }, { onConflict: 'user_id,month' });
      }
    } catch (error) { console.error(error); }
  };

  return (
    <Layout>
      <div className="max-w-3xl mx-auto space-y-6">
        <div>
          <h1 className="text-2xl lg:text-3xl font-display font-bold text-foreground">Log Your Activities</h1>
          <p className="text-muted-foreground mt-1">Track your carbon-producing activities to measure your environmental impact.</p>
        </div>

        {/* Info Cards */}
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
          {[
            { icon: Calendar, label: 'Daily', desc: 'Transport & habits', color: 'primary' },
            { icon: Utensils, label: 'Weekly', desc: 'Food & waste', color: 'chart-3' },
            { icon: Zap, label: 'Monthly', desc: 'Utilities & shopping', color: 'chart-4' },
          ].map((item, i) => (
            <motion.div key={item.label} initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.1 * (i + 1) }}>
              <Card className="card-hover">
                <CardContent className="p-4 flex items-center gap-3">
                  <div className={`w-10 h-10 rounded-lg bg-${item.color}/20 flex items-center justify-center`}>
                    <item.icon className={`w-5 h-5 text-${item.color}`} />
                  </div>
                  <div>
                    <p className="font-medium text-foreground">{item.label}</p>
                    <p className="text-sm text-muted-foreground">{item.desc}</p>
                  </div>
                </CardContent>
              </Card>
            </motion.div>
          ))}
        </div>

        {/* Forms */}
        <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.4 }}>
          <Card>
            <Tabs value={activeTab} onValueChange={setActiveTab}>
              <CardHeader className="pb-0">
                <TabsList className="w-full grid grid-cols-3">
                  <TabsTrigger value="daily" className="flex items-center gap-2">
                    <Car className="w-4 h-4" /><span className="hidden sm:inline">Daily</span>
                  </TabsTrigger>
                  <TabsTrigger value="weekly" className="flex items-center gap-2">
                    <Utensils className="w-4 h-4" /><span className="hidden sm:inline">Weekly</span>
                  </TabsTrigger>
                  <TabsTrigger value="monthly" className="flex items-center gap-2">
                    <Zap className="w-4 h-4" /><span className="hidden sm:inline">Monthly</span>
                  </TabsTrigger>
                </TabsList>
              </CardHeader>

              <CardContent className="pt-6">
                {/* Daily */}
                <TabsContent value="daily" className="mt-0">
                  <form onSubmit={handleDailySubmit} className="space-y-5">
                    <div className="space-y-4">
                      <div className="space-y-2">
                        <Label>Transportation Mode</Label>
                        <Select value={transportMode} onValueChange={setTransportMode}>
                          <SelectTrigger><SelectValue placeholder="Select transport mode" /></SelectTrigger>
                          <SelectContent>
                            {transportModes.map(m => (
                              <SelectItem key={m.value} value={m.value}>
                                <span className="flex items-center gap-2">{m.icon} {m.label}</span>
                              </SelectItem>
                            ))}
                          </SelectContent>
                        </Select>
                      </div>
                      <div className="space-y-2">
                        <Label htmlFor="distance">Distance Traveled (km)</Label>
                        <Input id="distance" type="number" step="0.1" min="0" placeholder="e.g., 25" value={transportDistance} onChange={e => setTransportDistance(e.target.value)} />
                      </div>
                      <div className="space-y-2">
                        <Label htmlFor="flight">Flight Hours (optional)</Label>
                        <div className="relative">
                          <Plane className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
                          <Input id="flight" type="number" step="0.5" min="0" placeholder="e.g., 2" className="pl-10" value={flightHours} onChange={e => setFlightHours(e.target.value)} />
                        </div>
                      </div>
                      <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                        <div className="space-y-2">
                          <Label className="flex items-center gap-2"><Droplets className="w-4 h-4" /> Water Used (liters)</Label>
                          <Input type="number" min="0" placeholder="e.g., 150" value={waterLiters} onChange={e => setWaterLiters(e.target.value)} />
                        </div>
                        <div className="space-y-2">
                          <Label className="flex items-center gap-2"><MonitorPlay className="w-4 h-4" /> Streaming (hours)</Label>
                          <Input type="number" step="0.5" min="0" placeholder="e.g., 3" value={streamingHours} onChange={e => setStreamingHours(e.target.value)} />
                        </div>
                      </div>
                    </div>
                    <Button type="submit" className="w-full" disabled={loading}>
                      {loading ? 'Saving...' : 'Log Daily Activity'} <Plus className="w-4 h-4" />
                    </Button>
                  </form>
                </TabsContent>

                {/* Weekly */}
                <TabsContent value="weekly" className="mt-0">
                  <form onSubmit={handleWeeklySubmit} className="space-y-5">
                    <div className="space-y-4">
                      <div className="space-y-2">
                        <Label>Primary Transportation Mode</Label>
                        <Select value={weeklyTransportMode} onValueChange={setWeeklyTransportMode}>
                          <SelectTrigger><SelectValue placeholder="Select your main transport" /></SelectTrigger>
                          <SelectContent>
                            {transportModes.map(m => (
                              <SelectItem key={m.value} value={m.value}>
                                <span className="flex items-center gap-2">{m.icon} {m.label}</span>
                              </SelectItem>
                            ))}
                          </SelectContent>
                        </Select>
                      </div>
                      <div className="space-y-2">
                        <Label htmlFor="weeklyDistance">Total Weekly Distance (km)</Label>
                        <Input id="weeklyDistance" type="number" step="1" min="0" placeholder="e.g., 150" value={weeklyDistance} onChange={e => setWeeklyDistance(e.target.value)} />
                      </div>
                      <div className="space-y-2">
                        <Label>Non-Vegetarian Days This Week</Label>
                        <Select value={nonVegDays} onValueChange={setNonVegDays}>
                          <SelectTrigger><SelectValue placeholder="Select days" /></SelectTrigger>
                          <SelectContent>
                            {[0,1,2,3,4,5,6,7].map(d => (
                              <SelectItem key={d} value={d.toString()}>{d} {d === 1 ? 'day' : 'days'}</SelectItem>
                            ))}
                          </SelectContent>
                        </Select>
                      </div>
                      <div className="space-y-2">
                        <Label className="flex items-center gap-2"><Trash2 className="w-4 h-4" /> Waste Produced (kg)</Label>
                        <Input type="number" step="0.5" min="0" placeholder="e.g., 5" value={wasteKg} onChange={e => setWasteKg(e.target.value)} />
                        <p className="text-xs text-muted-foreground">Estimate your household waste for the week</p>
                      </div>
                    </div>
                    <Button type="submit" className="w-full" disabled={loading}>
                      {loading ? 'Saving...' : 'Log Weekly Activity'} <Plus className="w-4 h-4" />
                    </Button>
                  </form>
                </TabsContent>

                {/* Monthly */}
                <TabsContent value="monthly" className="mt-0">
                  <form onSubmit={handleMonthlySubmit} className="space-y-5">
                    <div className="space-y-4">
                      <div className="space-y-2">
                        <Label htmlFor="electricity">Electricity Consumption (kWh)</Label>
                        <div className="relative">
                          <Zap className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
                          <Input id="electricity" type="number" step="1" min="0" placeholder="Check your electricity bill" className="pl-10" value={electricityUnits} onChange={e => setElectricityUnits(e.target.value)} />
                        </div>
                      </div>
                      <div className="space-y-2">
                        <Label htmlFor="gas">Gas/LPG Usage (kg)</Label>
                        <Input id="gas" type="number" step="0.5" min="0" placeholder="e.g., 14.2 for a cylinder" value={gasLpgKg} onChange={e => setGasLpgKg(e.target.value)} />
                        <p className="text-xs text-muted-foreground">Standard LPG cylinder ≈ 14.2 kg</p>
                      </div>
                      <div className="space-y-2">
                        <Label className="flex items-center gap-2"><ShoppingBag className="w-4 h-4" /> Shopping Items Purchased</Label>
                        <Input type="number" min="0" placeholder="Clothing, electronics, etc." value={shoppingItems} onChange={e => setShoppingItems(e.target.value)} />
                        <p className="text-xs text-muted-foreground">Count of new items bought this month</p>
                      </div>
                    </div>
                    <Button type="submit" className="w-full" disabled={loading}>
                      {loading ? 'Saving...' : 'Log Monthly Data'} <Plus className="w-4 h-4" />
                    </Button>
                  </form>
                </TabsContent>
              </CardContent>
            </Tabs>
          </Card>
        </motion.div>

        {/* Tips */}
        <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.5 }}>
          <Card className="bg-secondary/30">
            <CardHeader>
              <CardTitle className="text-lg flex items-center gap-2">
                <Check className="w-5 h-5 text-success" /> Quick Tips
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-3">
              {[
                { bold: 'Daily logs are optional', text: ' — use them for unusual or high-impact days.' },
                { bold: 'Weekly summaries', text: ' capture your typical patterns more accurately.' },
                { bold: 'Monthly data', text: ' from utility bills gives the most accurate energy measurements.' },
                { bold: 'New categories', text: ' — water, waste, streaming & shopping all count toward your footprint!' },
              ].map((tip, i) => (
                <div key={i} className="flex items-start gap-3">
                  <ChevronRight className="w-4 h-4 text-primary mt-1 flex-shrink-0" />
                  <p className="text-sm text-muted-foreground"><strong className="text-foreground">{tip.bold}</strong>{tip.text}</p>
                </div>
              ))}
            </CardContent>
          </Card>
        </motion.div>
      </div>
    </Layout>
  );
}
