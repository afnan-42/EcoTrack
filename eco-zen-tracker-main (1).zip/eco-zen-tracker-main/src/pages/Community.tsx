import { useEffect, useState } from 'react';
import { motion } from 'framer-motion';
import { 
  Trophy, 
  Users, 
  TrendingUp, 
  Medal, 
  Leaf,
  MapPin
} from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Layout } from '@/components/Layout';
import { useAuth } from '@/hooks/useAuth';
import { supabase } from '@/integrations/supabase/client';
import { format, startOfMonth } from 'date-fns';

interface CityStats {
  city_average: number;
  total_users: number;
  city_pincode: string;
}

interface UserRank {
  user_rank: number;
  percentile: number;
  user_footprint: number;
  total_users: number;
}

interface LeaderboardEntry {
  rank: number;
  user_name: string;
  total_kg: number;
}

export default function Community() {
  const { user } = useAuth();
  const [loading, setLoading] = useState(true);
  const [cityStats, setCityStats] = useState<CityStats | null>(null);
  const [userRank, setUserRank] = useState<UserRank | null>(null);
  const [leaderboard, setLeaderboard] = useState<LeaderboardEntry[]>([]);
  const [userProfile, setUserProfile] = useState<{ city_pincode: string } | null>(null);

  const currentMonth = format(startOfMonth(new Date()), 'yyyy-MM-dd');

  useEffect(() => {
    if (user) {
      fetchCommunityData();
    }
  }, [user]);

  const fetchCommunityData = async () => {
    if (!user) return;

    try {
      // Fetch user profile
      const { data: profile } = await supabase
        .from('profiles')
        .select('city_pincode')
        .eq('user_id', user.id)
        .single();

      setUserProfile(profile);

      // Fetch city stats using database function
      const { data: statsData } = await supabase
        .rpc('get_city_average', {
          p_user_id: user.id,
          p_month: currentMonth,
        });

      if (statsData && statsData.length > 0) {
        setCityStats(statsData[0]);
      }

      // Fetch user rank
      const { data: rankData } = await supabase
        .rpc('get_user_rank', {
          p_user_id: user.id,
          p_month: currentMonth,
        });

      if (rankData && rankData.length > 0 && rankData[0].user_rank) {
        setUserRank(rankData[0]);
      }

      // Fetch leaderboard
      const { data: leaderboardData } = await supabase
        .rpc('get_city_leaderboard', {
          p_user_id: user.id,
          p_month: currentMonth,
        });

      if (leaderboardData) {
        setLeaderboard(leaderboardData);
      }
    } catch (error) {
      console.error('Error fetching community data:', error);
    } finally {
      setLoading(false);
    }
  };

  const getMedalColor = (rank: number) => {
    switch (rank) {
      case 1:
        return 'text-yellow-500';
      case 2:
        return 'text-gray-400';
      case 3:
        return 'text-amber-600';
      default:
        return 'text-muted-foreground';
    }
  };

  if (loading) {
    return (
      <Layout>
        <div className="flex items-center justify-center h-96">
          <div className="animate-pulse-soft">
            <Leaf className="w-12 h-12 text-primary" />
          </div>
        </div>
      </Layout>
    );
  }

  return (
    <Layout>
      <div className="space-y-6 lg:space-y-8">
        {/* Header */}
        <div>
          <h1 className="text-2xl lg:text-3xl font-display font-bold text-foreground">
            Community Rankings
          </h1>
          <p className="text-muted-foreground mt-1 flex items-center gap-2">
            <MapPin className="w-4 h-4" />
            Comparing with users in your area ({userProfile?.city_pincode || 'Set your pincode in settings'})
          </p>
        </div>

        {/* Stats Overview */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 lg:gap-6">
          {/* Your Rank */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.1 }}
          >
            <Card className="card-hover h-full">
              <CardHeader className="pb-2">
                <CardTitle className="text-sm font-medium text-muted-foreground flex items-center gap-2">
                  <Trophy className="w-4 h-4" />
                  Your Rank
                </CardTitle>
              </CardHeader>
              <CardContent>
                {userRank ? (
                  <>
                    <div className="flex items-end gap-2">
                      <span className="text-4xl font-bold text-primary">
                        #{userRank.user_rank}
                      </span>
                      <span className="text-muted-foreground mb-1">
                        of {userRank.total_users}
                      </span>
                    </div>
                    <p className="text-sm text-success mt-2">
                      Better than {userRank.percentile.toFixed(0)}% in your city
                    </p>
                  </>
                ) : (
                  <p className="text-muted-foreground">
                    Log activities to see your rank
                  </p>
                )}
              </CardContent>
            </Card>
          </motion.div>

          {/* City Average */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.2 }}
          >
            <Card className="card-hover h-full">
              <CardHeader className="pb-2">
                <CardTitle className="text-sm font-medium text-muted-foreground flex items-center gap-2">
                  <TrendingUp className="w-4 h-4" />
                  City Average
                </CardTitle>
              </CardHeader>
              <CardContent>
                {cityStats ? (
                  <>
                    <div className="flex items-end gap-2">
                      <span className="text-4xl font-bold text-chart-3">
                        {cityStats.city_average.toFixed(0)}
                      </span>
                      <span className="text-muted-foreground mb-1">
                        kg CO₂/month
                      </span>
                    </div>
                    {userRank && (
                      <p className={`text-sm mt-2 ${
                        userRank.user_footprint < cityStats.city_average 
                          ? 'text-success' 
                          : 'text-warning'
                      }`}>
                        You're {Math.abs(userRank.user_footprint - cityStats.city_average).toFixed(0)} kg 
                        {userRank.user_footprint < cityStats.city_average ? ' below' : ' above'} average
                      </p>
                    )}
                  </>
                ) : (
                  <p className="text-muted-foreground">
                    No data for your city yet
                  </p>
                )}
              </CardContent>
            </Card>
          </motion.div>

          {/* Total Users */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.3 }}
          >
            <Card className="card-hover h-full">
              <CardHeader className="pb-2">
                <CardTitle className="text-sm font-medium text-muted-foreground flex items-center gap-2">
                  <Users className="w-4 h-4" />
                  Community Size
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="flex items-end gap-2">
                  <span className="text-4xl font-bold text-chart-4">
                    {cityStats?.total_users || 0}
                  </span>
                  <span className="text-muted-foreground mb-1">
                    users tracking
                  </span>
                </div>
                <p className="text-sm text-muted-foreground mt-2">
                  In {cityStats?.city_pincode || 'your area'}
                </p>
              </CardContent>
            </Card>
          </motion.div>
        </div>

        {/* Leaderboard */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.4 }}
        >
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Medal className="w-5 h-5 text-primary" />
                Top 10 Leaderboard - {format(new Date(), 'MMMM yyyy')}
              </CardTitle>
            </CardHeader>
            <CardContent>
              {leaderboard.length > 0 ? (
                <div className="space-y-3">
                  {leaderboard.map((entry, index) => (
                    <motion.div
                      key={index}
                      initial={{ opacity: 0, x: -20 }}
                      animate={{ opacity: 1, x: 0 }}
                      transition={{ delay: 0.1 * index }}
                      className={`flex items-center gap-4 p-4 rounded-lg ${
                        entry.rank <= 3 ? 'bg-secondary/50' : 'bg-muted/30'
                      } ${userRank && entry.rank === userRank.user_rank ? 'ring-2 ring-primary' : ''}`}
                    >
                      <div className={`w-8 h-8 flex items-center justify-center font-bold ${getMedalColor(entry.rank)}`}>
                        {entry.rank <= 3 ? (
                          <Medal className="w-6 h-6" />
                        ) : (
                          <span>#{entry.rank}</span>
                        )}
                      </div>
                      <div className="flex-1">
                        <p className="font-medium text-foreground">
                          {entry.user_name}
                          {userRank && entry.rank === userRank.user_rank && (
                            <span className="ml-2 text-xs text-primary">(You)</span>
                          )}
                        </p>
                      </div>
                      <div className="text-right">
                        <p className="font-semibold text-foreground">
                          {entry.total_kg.toFixed(0)} kg
                        </p>
                        <p className="text-xs text-muted-foreground">CO₂/month</p>
                      </div>
                    </motion.div>
                  ))}
                </div>
              ) : (
                <div className="text-center py-12">
                  <Users className="w-12 h-12 mx-auto text-muted-foreground/50 mb-4" />
                  <p className="text-muted-foreground">
                    No leaderboard data yet for your area.
                  </p>
                  <p className="text-sm text-muted-foreground mt-1">
                    Start logging activities to appear on the leaderboard!
                  </p>
                </div>
              )}
            </CardContent>
          </Card>
        </motion.div>

        {/* How Ranking Works */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.5 }}
        >
          <Card className="bg-gradient-nature">
            <CardHeader>
              <CardTitle className="text-lg">How Rankings Work</CardTitle>
            </CardHeader>
            <CardContent className="space-y-3 text-sm text-muted-foreground">
              <p>
                <strong className="text-foreground">Lower emissions = better rank.</strong> We compare your monthly carbon footprint with others in your city/pincode area.
              </p>
              <p>
                Rankings are calculated using: <code className="bg-muted px-2 py-1 rounded">rank = count(users with lower emissions) + 1</code>
              </p>
              <p>
                Your percentile shows what percentage of users have higher emissions than you. A higher percentile means you're doing better!
              </p>
            </CardContent>
          </Card>
        </motion.div>
      </div>
    </Layout>
  );
}
