import { useEffect, useState } from 'react';
import { motion } from 'framer-motion';
import {
  Trophy, Star, Flame, Target, Check, Plus, Loader2, Sparkles
} from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Progress } from '@/components/ui/progress';
import { Badge } from '@/components/ui/badge';
import { Layout } from '@/components/Layout';
import { useAuth } from '@/hooks/useAuth';
import { supabase } from '@/integrations/supabase/client';
import { useToast } from '@/hooks/use-toast';

interface Challenge {
  id: string;
  title: string;
  description: string;
  category: string;
  icon: string;
  target_value: number;
  target_unit: string;
  points: number;
  difficulty: string;
}

interface UserChallenge {
  id: string;
  challenge_id: string;
  status: string;
  progress: number;
  completed_at: string | null;
  started_at: string;
}

const difficultyColor: Record<string, string> = {
  easy: 'bg-success/15 text-success border-success/20',
  medium: 'bg-warning/15 text-warning border-warning/20',
  hard: 'bg-destructive/15 text-destructive border-destructive/20',
};

const categoryFilter = ['all', 'transport', 'food', 'energy', 'lifestyle', 'nature'];

export default function Challenges() {
  const { user } = useAuth();
  const { toast } = useToast();
  const [challenges, setChallenges] = useState<Challenge[]>([]);
  const [userChallenges, setUserChallenges] = useState<UserChallenge[]>([]);
  const [loading, setLoading] = useState(true);
  const [filter, setFilter] = useState('all');
  const [joining, setJoining] = useState<string | null>(null);

  useEffect(() => {
    if (user) fetchData();
  }, [user]);

  const fetchData = async () => {
    if (!user) return;
    try {
      const [{ data: ch }, { data: uc }] = await Promise.all([
        supabase.from('challenges').select('*'),
        supabase.from('user_challenges').select('*').eq('user_id', user.id),
      ]);
      if (ch) setChallenges(ch);
      if (uc) setUserChallenges(uc);
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  const joinChallenge = async (challengeId: string) => {
    if (!user) return;
    setJoining(challengeId);
    try {
      const { error } = await supabase.from('user_challenges').insert({
        user_id: user.id, challenge_id: challengeId, status: 'active', progress: 0,
      });
      if (error) throw error;
      toast({ title: 'Challenge accepted! 💪', description: 'Good luck!' });
      fetchData();
    } catch (err: any) {
      toast({ title: 'Error', description: err.message || 'Failed to join', variant: 'destructive' });
    } finally {
      setJoining(null);
    }
  };

  const updateProgress = async (ucId: string, challengeId: string, newProgress: number) => {
    if (!user) return;
    const challenge = challenges.find(c => c.id === challengeId);
    if (!challenge) return;

    const completed = newProgress >= challenge.target_value;
    try {
      await supabase.from('user_challenges').update({
        progress: Math.min(newProgress, challenge.target_value),
        status: completed ? 'completed' : 'active',
        completed_at: completed ? new Date().toISOString() : null,
      }).eq('id', ucId);

      if (completed) {
        toast({ title: '🎉 Challenge Completed!', description: `You earned ${challenge.points} eco-points!` });
      }
      fetchData();
    } catch (err) {
      console.error(err);
    }
  };

  const totalPoints = userChallenges
    .filter(uc => uc.status === 'completed')
    .reduce((sum, uc) => {
      const ch = challenges.find(c => c.id === uc.challenge_id);
      return sum + (ch?.points || 0);
    }, 0);

  const activeCount = userChallenges.filter(uc => uc.status === 'active').length;
  const completedCount = userChallenges.filter(uc => uc.status === 'completed').length;

  const filtered = filter === 'all'
    ? challenges
    : challenges.filter(c => c.category === filter);

  if (loading) {
    return (
      <Layout>
        <div className="flex items-center justify-center h-96">
          <Loader2 className="w-8 h-8 animate-spin text-primary" />
        </div>
      </Layout>
    );
  }

  return (
    <Layout>
      <div className="space-y-6 lg:space-y-8">
        {/* Header */}
        <div>
          <h1 className="text-2xl lg:text-3xl font-display font-bold text-foreground">
            Eco Challenges
          </h1>
          <p className="text-muted-foreground mt-1">
            Take on challenges to reduce your footprint and earn points!
          </p>
        </div>

        {/* Stats */}
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
          <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.1 }}>
            <Card className="card-hover">
              <CardContent className="p-5 flex items-center gap-4">
                <div className="w-12 h-12 rounded-xl bg-primary/10 flex items-center justify-center">
                  <Star className="w-6 h-6 text-primary" />
                </div>
                <div>
                  <p className="text-2xl font-bold text-foreground">{totalPoints}</p>
                  <p className="text-sm text-muted-foreground">Eco Points</p>
                </div>
              </CardContent>
            </Card>
          </motion.div>
          <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.2 }}>
            <Card className="card-hover">
              <CardContent className="p-5 flex items-center gap-4">
                <div className="w-12 h-12 rounded-xl bg-warning/10 flex items-center justify-center">
                  <Flame className="w-6 h-6 text-warning" />
                </div>
                <div>
                  <p className="text-2xl font-bold text-foreground">{activeCount}</p>
                  <p className="text-sm text-muted-foreground">Active</p>
                </div>
              </CardContent>
            </Card>
          </motion.div>
          <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.3 }}>
            <Card className="card-hover">
              <CardContent className="p-5 flex items-center gap-4">
                <div className="w-12 h-12 rounded-xl bg-success/10 flex items-center justify-center">
                  <Trophy className="w-6 h-6 text-success" />
                </div>
                <div>
                  <p className="text-2xl font-bold text-foreground">{completedCount}</p>
                  <p className="text-sm text-muted-foreground">Completed</p>
                </div>
              </CardContent>
            </Card>
          </motion.div>
        </div>

        {/* Filters */}
        <div className="flex gap-2 flex-wrap">
          {categoryFilter.map(cat => (
            <Button
              key={cat}
              variant={filter === cat ? 'default' : 'outline'}
              size="sm"
              onClick={() => setFilter(cat)}
              className="capitalize"
            >
              {cat}
            </Button>
          ))}
        </div>

        {/* Challenges Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {filtered.map((ch, i) => {
            const uc = userChallenges.find(u => u.challenge_id === ch.id);
            const isActive = uc?.status === 'active';
            const isCompleted = uc?.status === 'completed';
            const progressPct = uc ? (uc.progress / ch.target_value) * 100 : 0;

            return (
              <motion.div
                key={ch.id}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.05 * i }}
              >
                <Card className={`card-hover h-full ${isCompleted ? 'border-success/30 bg-success/5' : ''}`}>
                  <CardContent className="p-5 space-y-4">
                    <div className="flex items-start justify-between">
                      <div className="flex items-center gap-3">
                        <span className="text-2xl">{ch.icon}</span>
                        <div>
                          <h3 className="font-semibold text-foreground">{ch.title}</h3>
                          <p className="text-sm text-muted-foreground">{ch.description}</p>
                        </div>
                      </div>
                      <Badge variant="outline" className={difficultyColor[ch.difficulty]}>
                        {ch.difficulty}
                      </Badge>
                    </div>

                    <div className="flex items-center justify-between text-sm">
                      <span className="text-muted-foreground">{ch.target_value} {ch.target_unit}</span>
                      <span className="flex items-center gap-1 text-primary font-medium">
                        <Sparkles className="w-3 h-3" /> {ch.points} pts
                      </span>
                    </div>

                    {isActive && (
                      <div className="space-y-2">
                        <Progress value={progressPct} className="h-2" />
                        <div className="flex items-center justify-between">
                          <span className="text-xs text-muted-foreground">
                            {uc!.progress}/{ch.target_value} {ch.target_unit}
                          </span>
                          <Button
                            size="sm"
                            variant="outline"
                            onClick={() => updateProgress(uc!.id, ch.id, uc!.progress + 1)}
                          >
                            <Plus className="w-3 h-3 mr-1" /> Log Progress
                          </Button>
                        </div>
                      </div>
                    )}

                    {isCompleted && (
                      <div className="flex items-center gap-2 text-success text-sm font-medium">
                        <Check className="w-4 h-4" /> Completed! +{ch.points} points
                      </div>
                    )}

                    {!uc && (
                      <Button
                        className="w-full"
                        variant="outline"
                        onClick={() => joinChallenge(ch.id)}
                        disabled={joining === ch.id}
                      >
                        {joining === ch.id ? <Loader2 className="w-4 h-4 animate-spin mr-1" /> : <Target className="w-4 h-4 mr-1" />}
                        Accept Challenge
                      </Button>
                    )}
                  </CardContent>
                </Card>
              </motion.div>
            );
          })}
        </div>
      </div>
    </Layout>
  );
}
