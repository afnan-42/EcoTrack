import { useEffect, useState } from 'react';
import { motion } from 'framer-motion';
import { 
  TrendingDown, 
  TrendingUp, 
  Leaf, 
  Zap, 
  Car, 
  Utensils,
  Plane,
  Target,
  Calendar
} from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Layout } from '@/components/Layout';
import { useAuth } from '@/hooks/useAuth';
import { supabase } from '@/integrations/supabase/client';
import { 
  calculateMonthlyFootprint, 
  getCarbonLevel, 
  getCarbonLevelColor,
  MonthlyBreakdown 
} from '@/lib/carbonCalculations';
import { 
  PieChart, 
  Pie, 
  Cell, 
  ResponsiveContainer, 
  AreaChart, 
  Area, 
  XAxis, 
  YAxis, 
  Tooltip,
  Legend
} from 'recharts';
import { Link } from 'react-router-dom';
import { format, subMonths, startOfMonth } from 'date-fns';

const CHART_COLORS = [
  'hsl(150, 60%, 35%)',
  'hsl(35, 90%, 55%)',
  'hsl(180, 45%, 50%)',
  'hsl(25, 80%, 50%)',
];

interface Activity {
  input_type: string;
  transport_mode: string | null;
  transport_distance_km: number | null;
  non_veg_days: number | null;
  electricity_units: number | null;
  gas_lpg_kg: number | null;
  flight_hours: number | null;
}

export default function Dashboard() {
  const { user } = useAuth();
  const [loading, setLoading] = useState(true);
  const [currentMonth, setCurrentMonth] = useState<MonthlyBreakdown | null>(null);
  const [previousMonth, setPreviousMonth] = useState<MonthlyBreakdown | null>(null);
  const [monthlyTrend, setMonthlyTrend] = useState<Array<{ month: string; total: number }>>([]);

  useEffect(() => {
    if (user) {
      fetchDashboardData();
    }
  }, [user]);

  const fetchDashboardData = async () => {
    if (!user) return;

    try {
      const currentMonthStart = startOfMonth(new Date());
      const previousMonthStart = startOfMonth(subMonths(new Date(), 1));

      // Fetch current month activities
      const { data: currentActivities } = await supabase
        .from('carbon_activities')
        .select('*')
        .eq('user_id', user.id)
        .gte('activity_date', format(currentMonthStart, 'yyyy-MM-dd'))
        .lt('activity_date', format(subMonths(currentMonthStart, -1), 'yyyy-MM-dd'));

      // Fetch previous month activities
      const { data: prevActivities } = await supabase
        .from('carbon_activities')
        .select('*')
        .eq('user_id', user.id)
        .gte('activity_date', format(previousMonthStart, 'yyyy-MM-dd'))
        .lt('activity_date', format(currentMonthStart, 'yyyy-MM-dd'));

      // Fetch last 6 months of footprints for trend
      const { data: footprints } = await supabase
        .from('monthly_footprints')
        .select('*')
        .eq('user_id', user.id)
        .order('month', { ascending: true })
        .limit(6);

      if (currentActivities) {
        const mapped = currentActivities.map((a: Activity) => ({
          input_type: a.input_type as 'daily' | 'weekly' | 'monthly',
          transport_mode: a.transport_mode || undefined,
          transport_distance_km: a.transport_distance_km || undefined,
          non_veg_days: a.non_veg_days || undefined,
          electricity_units: a.electricity_units || undefined,
          gas_lpg_kg: a.gas_lpg_kg || undefined,
          flight_hours: a.flight_hours || undefined,
        }));
        setCurrentMonth(calculateMonthlyFootprint(mapped));
      }

      if (prevActivities) {
        const mapped = prevActivities.map((a: Activity) => ({
          input_type: a.input_type as 'daily' | 'weekly' | 'monthly',
          transport_mode: a.transport_mode || undefined,
          transport_distance_km: a.transport_distance_km || undefined,
          non_veg_days: a.non_veg_days || undefined,
          electricity_units: a.electricity_units || undefined,
          gas_lpg_kg: a.gas_lpg_kg || undefined,
          flight_hours: a.flight_hours || undefined,
        }));
        setPreviousMonth(calculateMonthlyFootprint(mapped));
      }

      if (footprints) {
        setMonthlyTrend(
          footprints.map((f) => ({
            month: format(new Date(f.month), 'MMM'),
            total: Number(f.total_kg),
          }))
        );
      }
    } catch (error) {
      console.error('Error fetching dashboard data:', error);
    } finally {
      setLoading(false);
    }
  };

  const carbonLevel = currentMonth ? getCarbonLevel(currentMonth.total_kg) : 'low';
  const percentChange = currentMonth && previousMonth && previousMonth.total_kg > 0
    ? ((currentMonth.total_kg - previousMonth.total_kg) / previousMonth.total_kg) * 100
    : 0;

  const pieData = currentMonth
    ? [
        { name: 'Transport', value: currentMonth.transport_kg, icon: Car },
        { name: 'Food', value: currentMonth.food_kg, icon: Utensils },
        { name: 'Energy', value: currentMonth.energy_kg, icon: Zap },
        { name: 'Other', value: currentMonth.other_kg, icon: Plane },
      ].filter((d) => d.value > 0)
    : [];

  if (loading) {
    return (
      <Layout>
        <div className="flex items-center justify-center h-96">
          <div className="animate-pulse-soft">
            <Leaf className="w-12 h-12 text-primary" />
          </div>
        </div>
      </Layout>
    );
  }

  return (
    <Layout>
      <div className="space-y-6 lg:space-y-8">
        {/* Header */}
        <div className="flex flex-col lg:flex-row lg:items-center lg:justify-between gap-4">
          <div>
            <h1 className="text-2xl lg:text-3xl font-display font-bold text-foreground">
              Your Carbon Dashboard
            </h1>
            <p className="text-muted-foreground mt-1">
              {format(new Date(), 'MMMM yyyy')} Overview
            </p>
          </div>
          <div className="flex gap-3">
            <Link to="/activities">
              <Button variant="hero" size="lg">
                <Calendar className="w-5 h-5" />
                Log Activity
              </Button>
            </Link>
          </div>
        </div>

        {/* Main Stats */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 lg:gap-6">
          {/* Total Footprint Card */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.1 }}
          >
            <Card className="card-hover overflow-hidden">
              <CardHeader className="pb-2">
                <CardTitle className="text-sm font-medium text-muted-foreground flex items-center gap-2">
                  <Target className="w-4 h-4" />
                  Monthly Footprint
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="flex items-end gap-2">
                  <span className={`text-3xl font-bold ${getCarbonLevelColor(carbonLevel)}`}>
                    {currentMonth?.total_kg.toFixed(0) || 0}
                  </span>
                  <span className="text-muted-foreground mb-1">kg CO₂</span>
                </div>
                {previousMonth && previousMonth.total_kg > 0 && (
                  <div className={`flex items-center gap-1 mt-2 text-sm ${
                    percentChange < 0 ? 'text-success' : 'text-destructive'
                  }`}>
                    {percentChange < 0 ? (
                      <TrendingDown className="w-4 h-4" />
                    ) : (
                      <TrendingUp className="w-4 h-4" />
                    )}
                    <span>{Math.abs(percentChange).toFixed(1)}% from last month</span>
                  </div>
                )}
              </CardContent>
            </Card>
          </motion.div>

          {/* Transport Card */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.2 }}
          >
            <Card className="card-hover">
              <CardHeader className="pb-2">
                <CardTitle className="text-sm font-medium text-muted-foreground flex items-center gap-2">
                  <Car className="w-4 h-4" />
                  Transport
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="flex items-end gap-2">
                  <span className="text-3xl font-bold text-chart-1">
                    {currentMonth?.transport_kg.toFixed(0) || 0}
                  </span>
                  <span className="text-muted-foreground mb-1">kg</span>
                </div>
              </CardContent>
            </Card>
          </motion.div>

          {/* Food Card */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.3 }}
          >
            <Card className="card-hover">
              <CardHeader className="pb-2">
                <CardTitle className="text-sm font-medium text-muted-foreground flex items-center gap-2">
                  <Utensils className="w-4 h-4" />
                  Food
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="flex items-end gap-2">
                  <span className="text-3xl font-bold text-chart-3">
                    {currentMonth?.food_kg.toFixed(0) || 0}
                  </span>
                  <span className="text-muted-foreground mb-1">kg</span>
                </div>
              </CardContent>
            </Card>
          </motion.div>

          {/* Energy Card */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.4 }}
          >
            <Card className="card-hover">
              <CardHeader className="pb-2">
                <CardTitle className="text-sm font-medium text-muted-foreground flex items-center gap-2">
                  <Zap className="w-4 h-4" />
                  Energy
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="flex items-end gap-2">
                  <span className="text-3xl font-bold text-chart-4">
                    {currentMonth?.energy_kg.toFixed(0) || 0}
                  </span>
                  <span className="text-muted-foreground mb-1">kg</span>
                </div>
              </CardContent>
            </Card>
          </motion.div>
        </div>

        {/* Charts Row */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {/* Breakdown Pie Chart */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.5 }}
          >
            <Card className="h-full">
              <CardHeader>
                <CardTitle className="text-lg font-semibold">Emission Breakdown</CardTitle>
              </CardHeader>
              <CardContent>
                {pieData.length > 0 ? (
                  <div className="h-64">
                    <ResponsiveContainer width="100%" height="100%">
                      <PieChart>
                        <Pie
                          data={pieData}
                          cx="50%"
                          cy="50%"
                          innerRadius={60}
                          outerRadius={90}
                          paddingAngle={4}
                          dataKey="value"
                          label={({ name, percent }) => `${name} ${(percent * 100).toFixed(0)}%`}
                          labelLine={false}
                        >
                          {pieData.map((_, index) => (
                            <Cell key={`cell-${index}`} fill={CHART_COLORS[index % CHART_COLORS.length]} />
                          ))}
                        </Pie>
                        <Tooltip
                          formatter={(value: number) => [`${value.toFixed(1)} kg CO₂`, '']}
                          contentStyle={{
                            backgroundColor: 'hsl(var(--card))',
                            border: '1px solid hsl(var(--border))',
                            borderRadius: '8px',
                          }}
                        />
                        <Legend />
                      </PieChart>
                    </ResponsiveContainer>
                  </div>
                ) : (
                  <div className="h-64 flex items-center justify-center text-muted-foreground">
                    <div className="text-center">
                      <Leaf className="w-12 h-12 mx-auto mb-3 opacity-50" />
                      <p>No activity data yet</p>
                      <Link to="/activities">
                        <Button variant="link" className="mt-2">Log your first activity</Button>
                      </Link>
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>
          </motion.div>

          {/* Trend Chart */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.6 }}
          >
            <Card className="h-full">
              <CardHeader>
                <CardTitle className="text-lg font-semibold">Monthly Trend</CardTitle>
              </CardHeader>
              <CardContent>
                {monthlyTrend.length > 0 ? (
                  <div className="h-64">
                    <ResponsiveContainer width="100%" height="100%">
                      <AreaChart data={monthlyTrend}>
                        <defs>
                          <linearGradient id="colorTotal" x1="0" y1="0" x2="0" y2="1">
                            <stop offset="5%" stopColor="hsl(150, 60%, 35%)" stopOpacity={0.3} />
                            <stop offset="95%" stopColor="hsl(150, 60%, 35%)" stopOpacity={0} />
                          </linearGradient>
                        </defs>
                        <XAxis 
                          dataKey="month" 
                          axisLine={false}
                          tickLine={false}
                          tick={{ fill: 'hsl(var(--muted-foreground))' }}
                        />
                        <YAxis 
                          axisLine={false}
                          tickLine={false}
                          tick={{ fill: 'hsl(var(--muted-foreground))' }}
                          width={50}
                        />
                        <Tooltip
                          formatter={(value: number) => [`${value.toFixed(1)} kg CO₂`, 'Total']}
                          contentStyle={{
                            backgroundColor: 'hsl(var(--card))',
                            border: '1px solid hsl(var(--border))',
                            borderRadius: '8px',
                          }}
                        />
                        <Area
                          type="monotone"
                          dataKey="total"
                          stroke="hsl(150, 60%, 35%)"
                          strokeWidth={3}
                          fill="url(#colorTotal)"
                        />
                      </AreaChart>
                    </ResponsiveContainer>
                  </div>
                ) : (
                  <div className="h-64 flex items-center justify-center text-muted-foreground">
                    <div className="text-center">
                      <TrendingDown className="w-12 h-12 mx-auto mb-3 opacity-50" />
                      <p>Not enough data for trend analysis</p>
                      <p className="text-sm mt-1">Keep logging activities!</p>
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>
          </motion.div>
        </div>

        {/* Quick Actions */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.7 }}
        >
          <Card className="bg-gradient-nature">
            <CardContent className="p-6">
              <div className="flex flex-col lg:flex-row items-center gap-6">
                <div className="flex-shrink-0">
                  <div className="w-16 h-16 rounded-2xl bg-primary flex items-center justify-center">
                    <Leaf className="w-8 h-8 text-primary-foreground" />
                  </div>
                </div>
                <div className="flex-1 text-center lg:text-left">
                  <h3 className="text-lg font-semibold text-foreground mb-1">
                    Get personalized tips to reduce your footprint
                  </h3>
                  <p className="text-muted-foreground">
                    Our AI assistant analyzes your data and provides actionable recommendations.
                  </p>
                </div>
                <Link to="/assistant">
                  <Button variant="hero" size="lg">
                    Chat with AI
                  </Button>
                </Link>
              </div>
            </CardContent>
          </Card>
        </motion.div>
      </div>
    </Layout>
  );
}
