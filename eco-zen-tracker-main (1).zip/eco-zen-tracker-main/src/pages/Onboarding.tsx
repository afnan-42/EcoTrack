import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { motion, AnimatePresence } from 'framer-motion';
import {
  Leaf, Car, Utensils, Zap, Droplets, ShoppingBag,
  MonitorPlay, Trash2, Plane, ArrowRight, ArrowLeft, Check, MapPin
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Card, CardContent } from '@/components/ui/card';
import { Progress } from '@/components/ui/progress';
import { Slider } from '@/components/ui/slider';
import { useAuth } from '@/hooks/useAuth';
import { supabase } from '@/integrations/supabase/client';
import { useToast } from '@/hooks/use-toast';
import { getTransportModes, estimateFromOnboarding, getCarbonLevel, getCarbonLevelColor } from '@/lib/carbonCalculations';
import { format } from 'date-fns';
import {
  PieChart, Pie, Cell, ResponsiveContainer, Tooltip
} from 'recharts';

const CHART_COLORS = [
  'hsl(150, 60%, 35%)',
  'hsl(35, 90%, 55%)',
  'hsl(180, 45%, 50%)',
  'hsl(25, 80%, 50%)',
];

const STEPS = [
  { icon: Leaf, title: 'Welcome', subtitle: 'Let\'s calculate your carbon footprint' },
  { icon: Car, title: 'Transport', subtitle: 'How do you get around?' },
  { icon: Utensils, title: 'Diet', subtitle: 'What do you eat?' },
  { icon: Zap, title: 'Energy', subtitle: 'Your home energy usage' },
  { icon: Droplets, title: 'Lifestyle', subtitle: 'Water, shopping & more' },
  { icon: Check, title: 'Results', subtitle: 'Your estimated footprint' },
];

export default function Onboarding() {
  const { user } = useAuth();
  const navigate = useNavigate();
  const { toast } = useToast();
  const [step, setStep] = useState(0);
  const [saving, setSaving] = useState(false);

  // Profile
  const [name, setName] = useState('');
  const [cityPincode, setCityPincode] = useState('');

  // Transport
  const [transportMode, setTransportMode] = useState('car');
  const [dailyCommuteKm, setDailyCommuteKm] = useState(10);
  const [flightHoursPerMonth, setFlightHoursPerMonth] = useState(0);

  // Diet
  const [nonVegDaysPerWeek, setNonVegDaysPerWeek] = useState(4);

  // Energy
  const [electricityUnits, setElectricityUnits] = useState(150);
  const [gasKg, setGasKg] = useState(14);

  // Lifestyle
  const [waterLitersPerDay, setWaterLitersPerDay] = useState(150);
  const [shoppingItemsPerMonth, setShoppingItemsPerMonth] = useState(3);
  const [streamingHoursPerDay, setStreamingHoursPerDay] = useState(2);
  const [wasteKgPerWeek, setWasteKgPerWeek] = useState(5);

  const transportModes = getTransportModes();
  const progress = ((step) / (STEPS.length - 1)) * 100;

  const footprint = estimateFromOnboarding({
    transportMode, dailyCommuteKm, nonVegDaysPerWeek,
    electricityUnits, gasKg, flightHoursPerMonth,
    waterLitersPerDay, shoppingItemsPerMonth,
    streamingHoursPerDay, wasteKgPerWeek,
  });

  const level = getCarbonLevel(footprint.total_kg);

  const handleComplete = async () => {
    if (!user) return;
    setSaving(true);

    try {
      // Update profile
      await supabase.from('profiles').update({
        name: name || user.email,
        city_pincode: cityPincode || '000000',
        onboarding_completed: true,
      }).eq('user_id', user.id);

      // Save initial activities
      const currentMonth = format(new Date(), 'yyyy-MM-01');
      const today = format(new Date(), 'yyyy-MM-dd');

      await supabase.from('carbon_activities').insert([
        {
          user_id: user.id, activity_date: today, input_type: 'daily',
          transport_mode: transportMode, transport_distance_km: dailyCommuteKm,
          streaming_hours: streamingHoursPerDay, water_liters: waterLitersPerDay,
        },
        {
          user_id: user.id, activity_date: today, input_type: 'weekly',
          non_veg_days: nonVegDaysPerWeek, waste_kg: wasteKgPerWeek,
        },
        {
          user_id: user.id, activity_date: today, input_type: 'monthly',
          electricity_units: electricityUnits, gas_lpg_kg: gasKg,
          flight_hours: flightHoursPerMonth, shopping_items: shoppingItemsPerMonth,
        },
      ]);

      // Save monthly footprint
      await supabase.from('monthly_footprints').upsert({
        user_id: user.id, month: currentMonth,
        total_kg: footprint.total_kg, transport_kg: footprint.transport_kg,
        food_kg: footprint.food_kg, energy_kg: footprint.energy_kg,
        other_kg: footprint.other_kg,
      }, { onConflict: 'user_id,month' });

      toast({ title: 'Profile set up!', description: 'Welcome to EcoTrack!' });
      navigate('/dashboard');
    } catch (error) {
      console.error(error);
      toast({ title: 'Error', description: 'Failed to save. Please try again.', variant: 'destructive' });
    } finally {
      setSaving(false);
    }
  };

  const pieData = [
    { name: 'Transport', value: footprint.transport_kg },
    { name: 'Food', value: footprint.food_kg },
    { name: 'Energy', value: footprint.energy_kg },
    { name: 'Other', value: footprint.other_kg },
  ].filter(d => d.value > 0);

  const nextStep = () => setStep(s => Math.min(s + 1, STEPS.length - 1));
  const prevStep = () => setStep(s => Math.max(s - 1, 0));

  return (
    <div className="min-h-screen bg-background flex items-center justify-center p-4">
      <div className="w-full max-w-lg">
        {/* Progress */}
        <div className="mb-6">
          <div className="flex items-center justify-between mb-2">
            <div className="flex items-center gap-2">
              <Leaf className="w-5 h-5 text-primary" />
              <span className="font-display font-bold text-foreground">EcoTrack</span>
            </div>
            <span className="text-sm text-muted-foreground">Step {step + 1} of {STEPS.length}</span>
          </div>
          <Progress value={progress} className="h-2" />
        </div>

        <AnimatePresence mode="wait">
          <motion.div
            key={step}
            initial={{ opacity: 0, x: 30 }}
            animate={{ opacity: 1, x: 0 }}
            exit={{ opacity: 0, x: -30 }}
            transition={{ duration: 0.3 }}
          >
            <Card className="border-border/50 shadow-lg">
              <CardContent className="p-6 space-y-6">
                {/* Step Header */}
                <div className="text-center">
                  {(() => {
                    const Icon = STEPS[step].icon;
                    return (
                      <div className="w-14 h-14 rounded-2xl bg-primary/10 flex items-center justify-center mx-auto mb-3">
                        <Icon className="w-7 h-7 text-primary" />
                      </div>
                    );
                  })()}
                  <h2 className="text-xl font-display font-bold text-foreground">{STEPS[step].title}</h2>
                  <p className="text-sm text-muted-foreground">{STEPS[step].subtitle}</p>
                </div>

                {/* Step 0: Welcome */}
                {step === 0 && (
                  <div className="space-y-4">
                    <div className="space-y-2">
                      <Label>Your Name</Label>
                      <Input placeholder="What should we call you?" value={name} onChange={e => setName(e.target.value)} />
                    </div>
                    <div className="space-y-2">
                      <Label className="flex items-center gap-2">
                        <MapPin className="w-4 h-4" /> City Pincode
                      </Label>
                      <Input placeholder="e.g., 110001" value={cityPincode} onChange={e => setCityPincode(e.target.value)} maxLength={10} />
                      <p className="text-xs text-muted-foreground">For community comparisons with nearby users</p>
                    </div>
                  </div>
                )}

                {/* Step 1: Transport */}
                {step === 1 && (
                  <div className="space-y-5">
                    <div className="space-y-2">
                      <Label>Primary Transport</Label>
                      <Select value={transportMode} onValueChange={setTransportMode}>
                        <SelectTrigger><SelectValue /></SelectTrigger>
                        <SelectContent>
                          {transportModes.map(m => (
                            <SelectItem key={m.value} value={m.value}>
                              <span className="flex items-center gap-2">{m.icon} {m.label}</span>
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </div>
                    <div className="space-y-3">
                      <Label>Daily Commute Distance: <span className="font-bold text-primary">{dailyCommuteKm} km</span></Label>
                      <Slider value={[dailyCommuteKm]} onValueChange={v => setDailyCommuteKm(v[0])} min={0} max={100} step={1} />
                      <div className="flex justify-between text-xs text-muted-foreground">
                        <span>0 km</span><span>100 km</span>
                      </div>
                    </div>
                    <div className="space-y-3">
                      <Label className="flex items-center gap-2"><Plane className="w-4 h-4" /> Flight Hours/Month: <span className="font-bold text-primary">{flightHoursPerMonth}h</span></Label>
                      <Slider value={[flightHoursPerMonth]} onValueChange={v => setFlightHoursPerMonth(v[0])} min={0} max={20} step={0.5} />
                    </div>
                  </div>
                )}

                {/* Step 2: Diet */}
                {step === 2 && (
                  <div className="space-y-5">
                    <div className="space-y-3">
                      <Label>Non-Veg Days Per Week: <span className="font-bold text-primary">{nonVegDaysPerWeek} days</span></Label>
                      <Slider value={[nonVegDaysPerWeek]} onValueChange={v => setNonVegDaysPerWeek(v[0])} min={0} max={7} step={1} />
                      <div className="flex justify-between text-xs text-muted-foreground">
                        <span>🌱 Fully Veg</span><span>🍖 Every Day</span>
                      </div>
                    </div>
                    <div className="bg-secondary/50 rounded-xl p-4">
                      <p className="text-sm text-muted-foreground">
                        <strong className="text-foreground">Did you know?</strong> A plant-based diet produces about 50% less CO₂ than a meat-heavy diet.
                      </p>
                    </div>
                  </div>
                )}

                {/* Step 3: Energy */}
                {step === 3 && (
                  <div className="space-y-5">
                    <div className="space-y-3">
                      <Label className="flex items-center gap-2"><Zap className="w-4 h-4" /> Monthly Electricity: <span className="font-bold text-primary">{electricityUnits} kWh</span></Label>
                      <Slider value={[electricityUnits]} onValueChange={v => setElectricityUnits(v[0])} min={0} max={500} step={5} />
                      <p className="text-xs text-muted-foreground">Check your electricity bill for kWh consumed</p>
                    </div>
                    <div className="space-y-3">
                      <Label>Gas/LPG Usage: <span className="font-bold text-primary">{gasKg} kg/month</span></Label>
                      <Slider value={[gasKg]} onValueChange={v => setGasKg(v[0])} min={0} max={50} step={1} />
                      <p className="text-xs text-muted-foreground">1 cylinder ≈ 14.2 kg</p>
                    </div>
                  </div>
                )}

                {/* Step 4: Lifestyle */}
                {step === 4 && (
                  <div className="space-y-5">
                    <div className="space-y-2">
                      <Label className="flex items-center gap-2"><Droplets className="w-4 h-4" /> Daily Water: <span className="font-bold text-primary">{waterLitersPerDay}L</span></Label>
                      <Slider value={[waterLitersPerDay]} onValueChange={v => setWaterLitersPerDay(v[0])} min={0} max={500} step={10} />
                    </div>
                    <div className="space-y-2">
                      <Label className="flex items-center gap-2"><ShoppingBag className="w-4 h-4" /> Shopping Items/Month: <span className="font-bold text-primary">{shoppingItemsPerMonth}</span></Label>
                      <Slider value={[shoppingItemsPerMonth]} onValueChange={v => setShoppingItemsPerMonth(v[0])} min={0} max={20} step={1} />
                    </div>
                    <div className="space-y-2">
                      <Label className="flex items-center gap-2"><MonitorPlay className="w-4 h-4" /> Streaming Hours/Day: <span className="font-bold text-primary">{streamingHoursPerDay}h</span></Label>
                      <Slider value={[streamingHoursPerDay]} onValueChange={v => setStreamingHoursPerDay(v[0])} min={0} max={12} step={0.5} />
                    </div>
                    <div className="space-y-2">
                      <Label className="flex items-center gap-2"><Trash2 className="w-4 h-4" /> Waste/Week: <span className="font-bold text-primary">{wasteKgPerWeek} kg</span></Label>
                      <Slider value={[wasteKgPerWeek]} onValueChange={v => setWasteKgPerWeek(v[0])} min={0} max={20} step={0.5} />
                    </div>
                  </div>
                )}

                {/* Step 5: Results */}
                {step === 5 && (
                  <div className="space-y-5">
                    <div className="text-center">
                      <p className="text-sm text-muted-foreground mb-1">Your estimated monthly footprint</p>
                      <p className={`text-5xl font-bold ${getCarbonLevelColor(level)}`}>
                        {footprint.total_kg.toFixed(0)}
                      </p>
                      <p className="text-muted-foreground">kg CO₂ per month</p>
                      <div className={`inline-block mt-2 px-3 py-1 rounded-full text-xs font-medium ${
                        level === 'low' ? 'bg-success/20 text-success' :
                        level === 'medium' ? 'bg-warning/20 text-warning' :
                        level === 'high' ? 'bg-carbon-high/20 text-carbon-high' :
                        'bg-destructive/20 text-destructive'
                      }`}>
                        {level === 'low' ? '🌱 Great!' : level === 'medium' ? '🌿 Average' : level === 'high' ? '⚠️ Above Average' : '🔴 High Impact'}
                      </div>
                    </div>

                    {pieData.length > 0 && (
                      <div className="h-48">
                        <ResponsiveContainer width="100%" height="100%">
                          <PieChart>
                            <Pie data={pieData} cx="50%" cy="50%" innerRadius={45} outerRadius={70} paddingAngle={4} dataKey="value"
                              label={({ name, percent }) => `${name} ${(percent * 100).toFixed(0)}%`} labelLine={false}>
                              {pieData.map((_, i) => <Cell key={i} fill={CHART_COLORS[i % CHART_COLORS.length]} />)}
                            </Pie>
                            <Tooltip formatter={(v: number) => [`${v.toFixed(1)} kg CO₂`, '']}
                              contentStyle={{ backgroundColor: 'hsl(var(--card))', border: '1px solid hsl(var(--border))', borderRadius: '8px' }} />
                          </PieChart>
                        </ResponsiveContainer>
                      </div>
                    )}

                    <div className="grid grid-cols-2 gap-3">
                      {[
                        { label: 'Transport', value: footprint.transport_kg, icon: '🚗' },
                        { label: 'Food', value: footprint.food_kg, icon: '🍽️' },
                        { label: 'Energy', value: footprint.energy_kg, icon: '⚡' },
                        { label: 'Other', value: footprint.other_kg, icon: '📦' },
                      ].map(item => (
                        <div key={item.label} className="bg-secondary/50 rounded-lg p-3 text-center">
                          <p className="text-lg">{item.icon}</p>
                          <p className="font-semibold text-foreground">{item.value.toFixed(0)} kg</p>
                          <p className="text-xs text-muted-foreground">{item.label}</p>
                        </div>
                      ))}
                    </div>
                  </div>
                )}

                {/* Navigation */}
                <div className="flex gap-3 pt-2">
                  {step > 0 && (
                    <Button variant="outline" onClick={prevStep} className="flex-1">
                      <ArrowLeft className="w-4 h-4 mr-1" /> Back
                    </Button>
                  )}
                  {step < STEPS.length - 1 ? (
                    <Button onClick={nextStep} className="flex-1">
                      Next <ArrowRight className="w-4 h-4 ml-1" />
                    </Button>
                  ) : (
                    <Button onClick={handleComplete} disabled={saving} className="flex-1" variant="default">
                      {saving ? 'Saving...' : 'Go to Dashboard'} <ArrowRight className="w-4 h-4 ml-1" />
                    </Button>
                  )}
                </div>
              </CardContent>
            </Card>
          </motion.div>
        </AnimatePresence>
      </div>
    </div>
  );
}
